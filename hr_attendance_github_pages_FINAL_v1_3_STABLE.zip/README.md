# نظام دوام ورواتب (واجهة فقط) — GitHub Pages

✅ عربي 100% — تصميم Mobile-First احترافي  
✅ يعمل بالكامل على GitHub Pages (بدون سيرفر)  
✅ Excel Import/Export + صك قبض PDF  
❌ لا يوجد GPS / لوكيشن  
⚠️ بدون سيرفر: المزامنة بين أجهزة مختلفة تحتاج "ملف مزامنة" (Export/Import) — موجود داخل النظام.

## تشغيل محلي (اختياري)
افتح `index.html` مباشرة بالمتصفح.

## نشر على GitHub Pages
1) ارفع الملفات على GitHub (Repository)
2) Settings → Pages
3) اختر: Deploy from a branch
4) Branch: main  /  folder: / (root)
5) Save
سيظهر لك رابط GitHub Pages.

## بيانات الدخول
### Admin (ثابت)
- المستخدم: admin
- كلمة السر: admin123

### Manager
- يتم إنشاؤه من لوحة Admin (إعدادات → مدراء)

### Employee
- دخول باسم الموظف فقط (من قائمة الموظفين)

## قوالب Excel
من داخل لوحة Admin:
- تصدير قالب الموظفين
- تصدير قالب الدوام
- استيراد/تصدير

